#ifndef AOWIS_EPANET_HYDRAULIC_SOLVER_H
#define AOWIS_EPANET_HYDRAULIC_SOLVER_H

#include <aowis/model/hydraulic/hydraulic_simulation_results.h>
#include <aowis/model/hydraulic/hydraulic_simulation_status.h>
#include <aowis/model/hydraulic/network_hydraulic.h>

class EpanetProject;
class EpanetResultReader;

class EpanetHydraulicSolver
{
public:
    EpanetHydraulicSolver(EpanetProject &project, const NetworkHydraulic &network, const EpanetResultReader &result_reader);

    HydraulicSimulationStatus run(HydraulicSimulationResultTimeline &timeline);

private:
    HydraulicSimulationStatus configureReport() const;

    EpanetProject &project;
    const NetworkHydraulic &network;
    const EpanetResultReader &result_reader;
};

#endif // AOWIS_EPANET_HYDRAULIC_SOLVER_H
