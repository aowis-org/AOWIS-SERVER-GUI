#ifndef AOWIS_MODEL_HYDRAULIC_NODES_H
#define AOWIS_MODEL_HYDRAULIC_NODES_H

#include <QList>
#include <QString>
#include <QUuid>

#include "../gis.h"
#include "hydraulic_demands.h"
#include "hydraulic_types.h"

struct HydraulicNodeJunctionEmitter
{
    // Q = coefficient * pressure_head^pressure_exponent, with Q in m3/h and pressure head in m.
    // The coefficient therefore has no fixed canonical UCUM unit independent of pressure_exponent.
    double coefficient = 0.0;
    double pressure_exponent = 0.5;
};

struct HydraulicNodeJunction
{
    QString id;
    QUuid uuid;

    CoordinateWGS84 coordinate_wgs84;

    HydraulicNodeElevationInputType elevation_input_type = HydraulicNodeElevationInputType::TotalElevation;
    double elevation_m = 0.0;
    double terrain_elevation_m = 0.0;
    double elevation_offset_m = 0.0;

    QList<HydraulicDemand> demands;

    HydraulicNodeJunctionEmitter emitter;

    double initial_chemical_concentration_mg_per_l = 0.0;
    double initial_water_age_h = 0.0;
    HydraulicNodeQualitySource quality_source;

    HydraulicEntityMetadata metadata;
};

struct HydraulicNodeReservoir
{
    QString id;
    QUuid uuid;

    CoordinateWGS84 coordinate_wgs84;

    HydraulicNodeElevationInputType head_input_type = HydraulicNodeElevationInputType::TotalHead;
    double hydraulic_head_m = 0.0;
    double terrain_elevation_m = 0.0;
    double hydraulic_head_offset_m = 0.0;
    HydraulicTimePatternMode head_pattern_mode = HydraulicTimePatternMode::Constant;
    QUuid head_pattern_uuid;

    double initial_chemical_concentration_mg_per_l = 0.0;
    double initial_water_age_h = 0.0;
    HydraulicNodeQualitySource quality_source;

    HydraulicEntityMetadata metadata;
};

struct HydraulicNodeTank
{
    QString id;
    QUuid uuid;

    CoordinateWGS84 coordinate_wgs84;

    HydraulicNodeTankElevationInputType elevation_input_type = HydraulicNodeTankElevationInputType::BottomElevation;
    double bottom_elevation_m = 0.0;
    double terrain_elevation_m = 0.0;
    double bottom_offset_m = 0.0;

    double water_level_initial_m = 0.0;
    double water_level_minimum_m = 0.0;
    double water_level_maximum_m = 0.0;

    HydraulicNodeTankGeometryInputType geometry_input_type = HydraulicNodeTankGeometryInputType::Cylindrical;
    double diameter_m = 0.0;
    double cross_section_area_m2 = 0.0;
    double volume_at_maximum_level_m3 = 0.0;
    double minimum_volume_m3 = 0.0;
    QUuid volume_curve_uuid;

    bool can_overflow = false;

    double initial_chemical_concentration_mg_per_l = 0.0;
    double initial_water_age_h = 0.0;
    HydraulicNodeQualitySource quality_source;

    HydraulicNodeTankMixingModel mixing_model = HydraulicNodeTankMixingModel::CompleteMix;
    double mixing_fraction = 1.0;

    bool override_bulk_reaction = false;
    WaterQualityBulkReaction bulk_reaction;

    HydraulicEntityMetadata metadata;
};

#endif // AOWIS_MODEL_HYDRAULIC_NODES_H
